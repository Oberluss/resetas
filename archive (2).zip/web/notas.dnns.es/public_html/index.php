<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Notas</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- React y ReactDOM -->
    <script crossorigin src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
    <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
    
    <!-- Babel -->
    <script src="https://unpkg.com/babel-standalone@6/babel.min.js"></script>

    <!-- jsPDF -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

    <!-- Archivo de estilos -->
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body class="bg-gray-50">
    <div id="root"></div>
    
    <script type="text/babel">
        const { useState } = React;

        const App = () => {
            const initialLines = Array(10).fill().map(() => ({ 
                units: '', 
                description: '', 
                price: '', 
                total: 0 
            }));

            const [clientData, setClientData] = useState({
                name: '',
                address: '',
                phone: '',
                date: new Date().toISOString().split('T')[0],
                documentType: 'nota'
            });

            const [invoiceLines, setInvoiceLines] = useState(initialLines);

            const calculateTotal = () => {
                return invoiceLines.reduce((sum, line) => sum + (line.total || 0), 0);
            };

            const updateLine = (index, field, value) => {
                const newLines = [...invoiceLines];
                newLines[index][field] = value;
                
                if (field === 'units' || field === 'price') {
                    const units = parseFloat(newLines[index].units) || 0;
                    const price = parseFloat(newLines[index].price) || 0;
                    newLines[index].total = units * price;
                }
                
                setInvoiceLines(newLines);
            };

            const guardarNota = async () => {
                try {
                    const response = await fetch('guardar_nota.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            nombre: clientData.name,
                            direccion: clientData.address,
                            telefono: clientData.phone,
                            tipo: clientData.documentType,
                            fecha: clientData.date,
                            total: calculateTotal(),
                            items: invoiceLines.filter(line => line.units || line.description || line.price)
                        })
                    });
                    
                    const result = await response.json();
                    if (result.success) {
                        alert('Nota guardada correctamente');
                    } else {
                        throw new Error(result.error);
                    }
                    
                } catch (error) {
                    console.error('Error:', error);
                    alert('Error al guardar la nota');
                }
            };

            return (
                <div className="min-h-screen bg-gray-50">
                    <header className="sticky top-0 bg-white shadow-md z-10">
                        <div className="container mx-auto px-4 py-4">
                            <h1 className="text-2xl md:text-3xl font-bold text-gray-800 text-center">
                                Sistema de Notas
                            </h1>
                        </div>
                    </header>
                    
                    <main className="container mx-auto px-4 py-6">
                        <div className="space-y-6">
                            {/* Fecha y Tipo de Documento */}
                            <div className="bg-white p-4 md:p-6 rounded-lg shadow-md">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-sm font-medium text-gray-600 mb-1">Fecha</label>
                                        <input
                                            type="date"
                                            value={clientData.date}
                                            onChange={(e) => setClientData({...clientData, date: e.target.value})}
                                            className="w-full p-2 border rounded"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-600 mb-1">Tipo de Documento</label>
                                        <select 
                                            value={clientData.documentType}
                                            onChange={(e) => setClientData({...clientData, documentType: e.target.value})}
                                            className="w-full p-2 border rounded"
                                        >
                                            <option value="nota">Nota</option>
                                            <option value="presupuesto">Presupuesto</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            {/* Datos del Cliente y Empresa */}
                            <div className="bg-white p-4 md:p-6 rounded-lg shadow-md">
                                <h2 className="text-lg md:text-xl font-semibold mb-4">Datos del Cliente</h2>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {/* Cliente */}
                                    <div className="space-y-3">
                                        <input
                                            type="text"
                                            placeholder="Nombre del cliente"
                                            value={clientData.name}
                                            onChange={(e) => setClientData({...clientData, name: e.target.value})}
                                            className="w-full p-3 border rounded shadow-sm"
                                        />
                                        <input
                                            type="text"
                                            placeholder="Dirección"
                                            value={clientData.address}
                                            onChange={(e) => setClientData({...clientData, address: e.target.value})}
                                            className="w-full p-3 border rounded shadow-sm"
                                        />
                                        <input
                                            type="tel"
                                            placeholder="Teléfono"
                                            value={clientData.phone}
                                            onChange={(e) => setClientData({...clientData, phone: e.target.value})}
                                            className="w-full p-3 border rounded shadow-sm"
                                        />
                                    </div>
                                    {/* Empresa */}
                                    {/* <div className="mt-4 md:mt-0 p-4 bg-gray-50 rounded-lg">
                                        <h3 className="font-bold mb-2">Datos de la Empresa</h3>
                                        <p className="text-gray-600">Tu Empresa S.L.</p>
                                        <p className="text-gray-600">Dirección de la empresa</p>
                                        <p className="text-gray-600">Teléfono: XXX-XXX-XXX</p>
                                    </div */}>
                                </div>
                            </div>

                            {/* Tabla de Detalles */}
                            <div className="bg-white p-4 md:p-6 rounded-lg shadow-md">
                                <h2 className="text-lg md:text-xl font-semibold mb-4">Detalles de la Nota</h2>
                                <div className="overflow-x-auto">
                                    <table className="w-full table-auto">
                                        <thead className="bg-gray-100">
                                            <tr>
                                                <th className="p-3 w-[10%]">Unidades</th>
                                                <th className="p-3 w-[55%]">Descripción</th>
                                                <th className="p-3 w-[10%]">Precio</th>
                                                <th className="p-3 w-[15%]">Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {invoiceLines.map((line, index) => (
                                                <tr key={index} className="border-b">
                                                    <td className="p-3">
                                                        <input
                                                            type="number"
                                                            value={line.units}
                                                            onChange={(e) => updateLine(index, 'units', e.target.value)}
                                                            className="w-full p-2 border rounded"
                                                        />
                                                    </td>
                                                    <td className="p-3">
                                                        <input
                                                            type="text"
                                                            value={line.description}
                                                            onChange={(e) => updateLine(index, 'description', e.target.value)}
                                                            className="w-full p-2 border rounded"
                                                        />
                                                    </td>
                                                    <td className="p-3">
                                                        <input
                                                            type="number"
                                                            value={line.price}
                                                            onChange={(e) => updateLine(index, 'price', e.target.value)}
                                                            className="w-full p-2 border rounded"
                                                        />
                                                    </td>
                                                    <td className="p-3 text-right">
                                                        {(line.total || 0).toFixed(2)} €
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                                <div className="mt-4 bg-gray-50 p-4 rounded-lg text-right">
                                    <span className="font-bold">Suma Total: </span>
                                    <span className="font-bold text-lg">{calculateTotal().toFixed(2)} €</span>
                                </div>
                            </div>
                        </div>

                        {/* Botones */}
                        <div className="mt-6 flex flex-col md:flex-row justify-end gap-2">
                            <button
                                className="w-full md:w-auto bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600 transition-colors"
                                onClick={guardarNota}
                            >
                                Guardar
                            </button>
                            <button
                                className="w-full md:w-auto bg-gray-500 text-white px-6 py-2 rounded-lg hover:bg-gray-600 transition-colors"
                                onClick={() => window.location.href = 'vernotas.php'}
                            >
                                Ver Notas
                            </button>
                        </div>
                    </main>
                </div>
            );
        };

        ReactDOM.render(<App />, document.getElementById('root'));
    </script>
</body>
</html>

