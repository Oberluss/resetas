<?php
$servername = "192.168.10.101";
$username = "oberlus";
$password = "Admin2018";
$dbname = "sistema_notas";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
   die("Conexión fallida: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
?>