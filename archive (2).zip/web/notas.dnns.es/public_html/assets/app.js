// app.js
const App = () => {
    return (
        <div className="container mx-auto px-4 py-8">
            <header className="mb-8">
                <h1 className="text-3xl font-bold text-gray-800">Sistema de Albaranes</h1>
            </header>
            <main>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Calendar />
                    <InvoiceForm />
                </div>
            </main>
        </div>
    );
};

// Renderizar la aplicación
ReactDOM.render(
    <App />,
    document.getElementById('root')
);