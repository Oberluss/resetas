<?php
require_once 'conexion.php';

if (!isset($_GET['id'])) {
    header('Location: vernotas.php');
    exit;
}

$nota_id = (int)$_GET['id'];

// Obtener datos de la nota y cliente
$sql = "SELECT 
            notas.*,
            clientes.nombre as cliente_nombre,
            clientes.direccion as cliente_direccion,
            clientes.telefono as cliente_telefono,
            clientes.id as cliente_id
        FROM notas 
        INNER JOIN clientes ON notas.cliente_id = clientes.id 
        WHERE notas.id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $nota_id);
$stmt->execute();
$nota = $stmt->get_result()->fetch_assoc();

if (!$nota) {
    header('Location: vernotas.php');
    exit;
}

// Obtener items de la nota
$sql_items = "SELECT * FROM nota_items WHERE nota_id = ? ORDER BY id ASC";
$stmt_items = $conn->prepare($sql_items);
$stmt_items->bind_param("i", $nota_id);
$stmt_items->execute();
$items = $stmt_items->get_result()->fetch_all(MYSQLI_ASSOC);

// Si se envía el formulario para actualizar
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn->begin_transaction();

        // Actualizar cliente
        $stmt = $conn->prepare("UPDATE clientes SET nombre = ?, direccion = ?, telefono = ? WHERE id = ?");
        $stmt->bind_param("sssi", 
            $_POST['nombre'],
            $_POST['direccion'],
            $_POST['telefono'],
            $nota['cliente_id']
        );
        $stmt->execute();

        // Actualizar nota
        $stmt = $conn->prepare("UPDATE notas SET tipo = ?, fecha = ?, total = ? WHERE id = ?");
        $stmt->bind_param("ssdi", 
            $_POST['tipo'],
            $_POST['fecha'],
            $_POST['total'],
            $nota_id
        );
        $stmt->execute();

        // Eliminar items antiguos
        $stmt = $conn->prepare("DELETE FROM nota_items WHERE nota_id = ?");
        $stmt->bind_param("i", $nota_id);
        $stmt->execute();

        // Insertar nuevos items
        $stmt = $conn->prepare("INSERT INTO nota_items (nota_id, unidades, descripcion, precio, total) VALUES (?, ?, ?, ?, ?)");
        
        foreach ($_POST['items'] as $item) {
            if (!empty($item['unidades']) || !empty($item['descripcion']) || !empty($item['precio'])) {
                $stmt->bind_param("idsdd", 
                    $nota_id,
                    $item['unidades'],
                    $item['descripcion'],
                    $item['precio'],
                    $item['total']
                );
                $stmt->execute();
            }
        }

        $conn->commit();
        header('Location: vernota.php?id=' . $nota_id);
        exit;

    } catch (Exception $e) {
        $conn->rollback();
        $error = "Error al actualizar la nota: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar <?php echo ucfirst($nota['tipo']); ?> #<?php echo $nota['id']; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
    <script src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
    <script src="https://unpkg.com/babel-standalone@6/babel.min.js"></script>
</head>
<body class="bg-gray-50">
    <div id="root"></div>

    <script type="text/babel">
        const App = () => {
            const initialData = {
                tipo: '<?php echo $nota['tipo']; ?>',
                fecha: '<?php echo $nota['fecha']; ?>',
                nombre: '<?php echo addslashes($nota['cliente_nombre']); ?>',
                direccion: '<?php echo addslashes($nota['cliente_direccion']); ?>',
                telefono: '<?php echo addslashes($nota['cliente_telefono']); ?>',
                items: <?php echo json_encode($items); ?>,
                total: <?php echo $nota['total']; ?>
            };

            const [formData, setFormData] = useState(initialData);
            const [items, setItems] = useState(initialData.items);

            const calculateTotal = () => {
                return items.reduce((sum, item) => sum + (parseFloat(item.total) || 0), 0);
            };

            const updateItem = (index, field, value) => {
                const newItems = [...items];
                newItems[index][field] = value;
                
                if (field === 'unidades' || field === 'precio') {
                    const unidades = parseFloat(newItems[index].unidades) || 0;
                    const precio = parseFloat(newItems[index].precio) || 0;
                    newItems[index].total = unidades * precio;
                }
                
                setItems(newItems);
            };

            const handleSubmit = (e) => {
                e.preventDefault();
                const form = e.target;
                form.submit();
            };

            return (
                <div className="container mx-auto px-4 py-8">
                    <div className="flex justify-between items-center mb-6">
                        <h1 className="text-2xl font-bold text-gray-800">
                            Editar {formData.tipo.charAt(0).toUpperCase() + formData.tipo.slice(1)} #{<?php echo $nota_id; ?>}
                        </h1>
                        <a href="vernotas.php" className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">
                            Volver
                        </a>
                    </div>

                    <form onSubmit={handleSubmit} method="POST">
                        {/* Tipo y Fecha */}
                        <div className="bg-white p-6 rounded-lg shadow-md mb-6">
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Tipo de Documento
                                    </label>
                                    <select 
                                        name="tipo"
                                        value={formData.tipo}
                                        onChange={(e) => setFormData({...formData, tipo: e.target.value})}
                                        className="w-full p-2 border rounded"
                                    >
                                        <option value="nota">Nota</option>
                                        <option value="presupuesto">Presupuesto</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Fecha
                                    </label>
                                    <input
                                        type="date"
                                        name="fecha"
                                        value={formData.fecha}
                                        onChange={(e) => setFormData({...formData, fecha: e.target.value})}
                                        className="w-full p-2 border rounded"
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Datos del Cliente */}
                        <div className="bg-white p-6 rounded-lg shadow-md mb-6">
                            <h2 className="text-lg font-semibold mb-4">Datos del Cliente</h2>
                            <div className="grid grid-cols-1 gap-4">
                                <input
                                    type="text"
                                    name="nombre"
                                    placeholder="Nombre"
                                    value={formData.nombre}
                                    onChange={(e) => setFormData({...formData, nombre: e.target.value})}
                                    className="w-full p-2 border rounded"
                                />
                                <input
                                    type="text"
                                    name="direccion"
                                    placeholder="Dirección"
                                    value={formData.direccion}
                                    onChange={(e) => setFormData({...formData, direccion: e.target.value})}
                                    className="w-full p-2 border rounded"
                                />
                                <input
                                    type="text"
                                    name="telefono"
                                    placeholder="Teléfono"
                                    value={formData.telefono}
                                    onChange={(e) => setFormData({...formData, telefono: e.target.value})}
                                    className="w-full p-2 border rounded"
                                />
                            </div>
                        </div>

                        {/* Tabla de Items */}
                        <div className="bg-white p-6 rounded-lg shadow-md mb-6">
                            <h2 className="text-lg font-semibold mb-4">Items</h2>
                            <table className="w-full mb-4">
                                <thead>
                                    <tr>
                                        <th className="text-left">Unidades</th>
                                        <th className="text-left">Descripción</th>
                                        <th className="text-left">Precio</th>
                                        <th className="text-left">Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {items.map((item, index) => (
                                        <tr key={index}>
                                            <td className="py-2">
                                                <input
                                                    type="number"
                                                    name={`items[${index}][unidades]`}
                                                    value={item.unidades}
                                                    onChange={(e) => updateItem(index, 'unidades', e.target.value)}
                                                    className="w-full p-2 border rounded"
                                                />
                                            </td>
                                            <td className="py-2">
                                                <input
                                                    type="text"
                                                    name={`items[${index}][descripcion]`}
                                                    value={item.descripcion}
                                                    onChange={(e) => updateItem(index, 'descripcion', e.target.value)}
                                                    className="w-full p-2 border rounded"
                                                />
                                            </td>
                                            <td className="py-2">
                                                <input
                                                    type="number"
                                                    name={`items[${index}][precio]`}
                                                    value={item.precio}
                                                    onChange={(e) => updateItem(index, 'precio', e.target.value)}
                                                    className="w-full p-2 border rounded"
                                                />
                                            </td>
                                            <td className="py-2">
                                                <input
                                                    type="number"
                                                    name={`items[${index}][total]`}
                                                    value={item.total}
                                                    readOnly
                                                    className="w-full p-2 border rounded bg-gray-50"
                                                />
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>

                            <div className="text-right">
                                <span className="font-bold">Total: </span>
                                <input
                                    type="number"
                                    name="total"
                                    value={calculateTotal()}
                                    readOnly
                                    className="border rounded p-2 bg-gray-50"
                                />
                            </div>
                        </div>

                        <div className="flex justify-end gap-4">
                            <button
                                type="submit"
                                className="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600"
                            >
                                Guardar Cambios
                            </button>
                            
                                href="vernotas.php"
                                className="bg-gray-500 text-white px-6 py-2 rounded hover:bg-gray-600"
                            >
                                Cancelar
                            </a>
                        </div>
                    </form>
                </div>
            );
        };

        ReactDOM.render(<App />, document.getElementById('root'));
    </script>
</body>
</html>
